
        /*################################################################*/
        /*################################################################*/
        /*####                                                        ####*/
        /*####       EHP Italy S.p.A. (CTI Software Development)      ####*/
        /*####                                                        ####*/
        /*################################################################*/
        /*####                                                        ####*/
        /*####  Filter Driver Interface (FTDMACS.h)                   ####*/
        /*####                                                        ####*/
        /*####  This file provides the interface to the device        ####*/
        /*####  upper filter driver that implements the acknowledge   ####*/
        /*####  generation for the MACS protocol in kernel-mode.      ####/
        /*####                                                        ####*/
        /*################################################################*/
        /*####                                                        ####*/
        /*####  Activity       : NA                                   ####*/
        /*####                                                        ####*/
        /*####  Product        : Direct Macs Communication Library    ####*/
        /*####                                                        ####*/
        /*####  Version        : 1.1 (macs.sys filter driver)         ####*/
        /*####                                                        ####*/
        /*####  Date           : 25/01/2008                           ####*/
        /*####                                                        ####*/
        /*####  Programmer     : Andy Miller (FTDI)                   ####*/
        /*####                                                        ####*/
        /*################################################################*/
        /*################################################################*/


#ifndef __ftdmacs_h__
#define __ftdmacs_h__


#include "ftd2xx.h"


#ifdef __cplusplus
extern "C" {
#endif


// The following ifdef block is the standard way of creating macros which make exporting 
// from a DLL simpler. All files within this DLL are compiled with the FTDMACS_EXPORTS
// symbol defined on the command line. this symbol should not be defined on any project
// that uses this DLL. This way any other project whose source files include this file see 
// FTDMACS_API functions as being imported from a DLL, whereas this DLL sees symbols
// defined with this macro as being exported.

/* Define FTDMACS_API calling convention macro (Microsoft Visual C++) */
#ifdef FTDMACS_EXPORTS
#define FTDMACS_API __declspec(dllexport) __stdcall
#else
#define FTDMACS_API __declspec(dllimport) __stdcall
#endif

#ifndef TYPE_INTERFACE_DEF
#define TYPE_INTERFACE_DEF

/* Define a signed 8-bit integer */
typedef signed char Int8;

/* Define an unsigned 8-bit integer */
typedef unsigned char uInt8;

/* Define a signed 16-bit integer */
typedef signed short int Int16;

/* Define an unsigned 16-bit integer */
typedef unsigned short int uInt16;

/* Define a signed 32-bit integer */
typedef signed long int Int32;

/* Define an unsigned 32-bit integer */
typedef unsigned long int uInt32;

#endif

/**************************************************************************************************/
/*                                     ELUX_GetFTDMacsLibraryVersion                              */
/**************************************************************************************************/
/* TASK: this function returns the version number of the FTDMACS library.                         */
/* PARAMETERS: pui16MajorVersion -> it yields the major version number                            */
/*	           pui16MinorVersion -> it yields the minor version number                            */
/* RETURNS: None.                                                                                 */
/* NOTES: None.                                                                                   */
/**************************************************************************************************/
void 
FTDMACS_API ELUX_GetFTDMacsLibraryVersion(
	uInt16 *pui16MajorVersion,
	uInt16 *pui16MinorVersion
	);

/**************************************************************************************************/
/*                                            ELUX_Open                                           */
/**************************************************************************************************/
/* TASK: this function opens a Macs device and returns a handle that is used for subsequent       */
/*       communication with the device.                                                           */
/* PARAMETERS: ui32Loc		-> the location ID                                                    */
/*             pftHandle    -> pointer to FT_HANDLE                                               */
/* RETURNS: FT_OK if success                                                                      */
/*          FT_INSUFFICIENT_RESOURCES if no channels are available                                */
/* NOTES: this function calls FT_OpenEx to obtain an FT_HANDLE, and this handle can be used with  */
/*        FT_xxx and ELUX_xxx calls.                                                              */
/**************************************************************************************************/
FT_STATUS
FTDMACS_API ELUX_Open(
	uInt32 ui32Loc,
	FT_HANDLE *pftHandle
	);

/**************************************************************************************************/
/*                                            ELUX_Close                                          */
/**************************************************************************************************/
/* TASK: this function closes a Macs device.                                                      */
/* PARAMETERS: ftHandle    -> FT_HANDLE obtained from ELUX_Open                                   */
/* RETURNS: FT_OK if success                                                                      */
/*          FT_INVALID_HANDLE device is not recognised                                            */
/* NOTES: this function also closes the corresponding D2XX device.                                */
/**************************************************************************************************/
FT_STATUS
FTDMACS_API
ELUX_Close(
	FT_HANDLE ftHandle
	);

/**************************************************************************************************/
/*                                    ELUX_SetMacsProperties                                      */
/**************************************************************************************************/
/* TASK: this function assigns or resets the MACS protocol properties for the default             */
/*       impersonated unit.                                                                       */
/* TASK: this function assigns or resets the Macs protocol properties.                            */
/* PARAMETERS: ftHandle					-> FT_HANDLE obtained from ELUX_Open                      */
/*             ui8UnitCode				-> Unit Code (0..31)                                      */
/*	           ui8UnitDistCode			-> Unit Distinctive Code (0..7)                           */
/*	           ui16AckDelay				-> time to wait before generating the acknowledge message */
/*                                         (6..65535) (in ms)                                     */
/*	           ui16InitialReqRecTimeout	-> initial receive timeout value for MACS request message */
/*                                         The MACS Upper Filter driver works well for values     */
/*                                         equal to or greater than 15ms (60ms is the default)    */
/*	           ui16AckRecTimeout		-> receive timeout value for MACS acknowledge messages    */
/*                                         The MACS Upper Filter driver works well for values     */
/*                                         equal to or greater than 1ms (20ms is the default)     */
/* RETURNS: FT_OK if success                                                                      */
/*          FT_INVALID_HANDLE if device is not recognised                                         */
/*          FT_INVALID_PARAMETER if parameters are incorrect                                      */
/* NOTES: calling this function has the same effect as calling ELUX_SetMacsPropertiesEx with      */
/*        ui8TabUnitPos=0                                                                         */
/**************************************************************************************************/
FT_STATUS
FTDMACS_API ELUX_SetMacsProperties(
	FT_HANDLE ftHandle,
	uInt8 ui8UnitCode,
	uInt8 ui8UnitDistCode,
	uInt16 ui16AckDelay,
	uInt16 ui16InitialReqRecTimeout,
	uInt16 ui16AckRecTimeout
	);

/**************************************************************************************************/
/*                                    ELUX_GetMacsProperties                                      */
/**************************************************************************************************/
/* TASK: this function returns the currently assigned Macs properties of the default impersonated */
/*       unit.                                                                                    */
/* PARAMETERS: ftHandle						-> FT_HANDLE obtained from ELUX_Open                  */
/*             pui8UnitCode					-> it yields the Unit Code                            */
/*	           pui8UnitDistCode				-> it yields the Unit Distinctive Code                */
/*	           pui16AckDelay				-> it yields the time to wait before generatring the  */
/*                                             acknowledge messages (in ms)                       */
/*	           pui16InitialReqRecTimeout	-> it yields the initial receive timeout value for    */
/*                                             MACS request messages (in ms)                      */
/*	           pui16AckRecTimeout			-> it yields the receive timeout value for MACS       */
/*                                             acknowledge messages (in ms)                       */
/* RETURNS: FT_OK if success                                                                      */
/*          FT_INVALID_HANDLE if device is not recognised                                         */
/*          FT_INVALID_PARAMETER if parameters are incorrect                                      */
/* NOTES: calling this function has the same effect as calling ELUX_GetMacsPropertiesEx with      */
/*        ui8TabUnitPos=0                                                                         */
/**************************************************************************************************/
FT_STATUS
FTDMACS_API ELUX_GetMacsProperties(
	FT_HANDLE ftHandle,
	uInt8 *pui8UnitCode,
	uInt8 *pui8UnitDistCode,
	uInt16 *pui16AckDelay,
	uInt16 *pui16InitialReqRecTimeout,
	uInt16 *pui16AckRecTimeout
	);

/**************************************************************************************************/
/*                                    ELUX_SetMacsPropertiesEx                                    */
/**************************************************************************************************/
/* TASK: this function assigns or resets the MACS protocol properties for the specified           */
/*       impersonated unit (ui8TabUnitPos).                                                       */
/* TASK: this function assigns or resets the Macs protocol properties.                            */
/* PARAMETERS: ftHandle					-> FT_HANDLE obtained from ELUX_Open                      */
/*             ui8TabUnitPos			-> index to internal MACS address table item (0..4)       */
/*             ui8UnitCode				-> Unit Code (0..31)                                      */
/*	           ui8UnitDistCode			-> Unit Distinctive Code (0..7)                           */
/*	           ui16AckDelay				-> time to wait before generating the acknowledge message */
/*                                         (6..65535) (in ms)                                     */
/*	           ui16InitialReqRecTimeout	-> initial receive timeout value for MACS request message */
/*                                         The MACS Upper Filter driver works well for values     */
/*                                         equal to or greater than 15ms (60ms is the default)    */
/*	           ui16AckRecTimeout		-> receive timeout value for MACS acknowledge messages    */
/*                                         The MACS Upper Filter driver works well for values     */
/*                                         equal to or greater than 1ms (20ms is the default)     */
/* RETURNS: FT_OK if success                                                                      */
/*          FT_INVALID_HANDLE if device is not recognised                                         */
/*          FT_INVALID_PARAMETER if parameters are incorrect                                      */
/* NOTES: you can set ui8UnitCode and ui8UnitDistCode to zero to restore the initial condition    */
/*        (address not assigned).                                                                 */
/**************************************************************************************************/
FT_STATUS
FTDMACS_API ELUX_SetMacsPropertiesEx(
	FT_HANDLE ftHandle,
	uInt8 ui8TabUnitPos,
	uInt8 ui8UnitCode,
	uInt8 ui8UnitDistCode,
	uInt16 ui16AckDelay,
	uInt16 ui16InitialReqRecTimeout,
	uInt16 ui16AckRecTimeout
	);

/**************************************************************************************************/
/*                                    ELUX_GetMacsPropertiesEx                                    */
/**************************************************************************************************/
/* TASK: this function returns the currently assigned MACS properties of the specified unit       */
/*       (ui8TabUnitPos).                                                                         */
/* PARAMETERS: ftHandle						-> FT_HANDLE obtained from ELUX_Open                  */
/*             ui8TabUnitPos				-> index to internal MACS address table item (0..4)   */
/*             pui8UnitCode					-> it yields the Unit Code                            */
/*	           pui8UnitDistCode				-> it yields the Unit Distinctive Code                */
/*	           pui16AckDelay				-> it yields the time to wait before generatring the  */
/*                                             acknowledge messages (in ms)                       */
/*	           pui16InitialReqRecTimeout	-> it yields the initial receive timeout value for    */
/*                                             MACS request messages (in ms)                      */
/*	           pui16AckRecTimeout			-> it yields the receive timeout value for MACS       */
/*                                             acknowledge messages (in ms)                       */
/* RETURNS: FT_OK if success                                                                      */
/*          FT_INVALID_HANDLE if device is not recognised                                         */
/*          FT_INVALID_PARAMETER if parameters are incorrect                                      */
/* NOTES: None.                                                                                   */
/**************************************************************************************************/
FT_STATUS
FTDMACS_API ELUX_GetMacsPropertiesEx(
	FT_HANDLE ftHandle,
	uInt8 ui8TabUnitPos,
	uInt8 *pui8UnitCode,
	uInt8 *pui8UnitDistCode,
	uInt16 *pui16AckDelay,
	uInt16 *pui16InitialReqRecTimeout,
	uInt16 *pui16AckRecTimeout
	);



#ifdef __cplusplus
}
#endif


#endif /* __ftdmacs_h__ */
